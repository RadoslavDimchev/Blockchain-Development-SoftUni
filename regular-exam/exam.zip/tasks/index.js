require("./deploy");
require("./storeFunds");
